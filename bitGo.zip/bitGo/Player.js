class Player {
  constructor(name, piece) {
    this.name = name;
    this.piece = piece;
  }

  throw() {
    let max = 6;
    // Dice class is present is
    return Math.floor(Math.random() * max);
  }
}
