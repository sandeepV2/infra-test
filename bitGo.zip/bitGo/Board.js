class Board {
  #numOfCells;
  constructor(numOfCells) {
    this.numOfCells = numOfCells;
    this.snakes = [];
    this.ladder = [];
    this.players = [];
    this.posPiece1 = 0;
    this.posPiece2 = 0;
  }

  addSnake(snakeObj) {
    this.snakes.push(snakeObj);
  }

  addLadder(ladderObj) {
    this.ladder.push(ladderObj);
  }

  initPlayer(playerObj) {
    this.players.push(playerObj);
  }

  move(playerObj){
    pos + diceRandom
    // psudocode.
    while (snakes)
    at pos (if snake)
    end point , 
    move player cell 

    at pos 
  }
}

module.exports = { Board };
