class BoardElements {
  #start;
  #end;
  constructor(start, end) {
    this.start = start;
    this.end = end;
  }
}

class Snake extends BoardElements {
  constructor(start, end, id) {
    this.id = id;
    super(start, end);
  }
}

class Ladder extends BoardElements {
  constructor(start, end, id) {
    this.id = id;
    super(start, end);
  }
}

module.exports = { Snake, Ladder };
