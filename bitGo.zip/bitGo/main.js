const { Board } = require("./Board");
const { Snake, Ladder } = require("./BoadElements");

// import Board from "./Board";

let b = new Board(100);
let snakeObj = Snake(3, 10, "snake1");
let ladderObj = Ladder(2, 100, "ladder1");

b.addSnake(snakeObj);
b.addLadder(ladderObj);
let p1 = new Player("A", "p1");
let dice1 = p1.throw();

let p2 = new Player("B", "p2");
let dice2 = p2.throw();

b.move(p1);

// main > Board
Board;
